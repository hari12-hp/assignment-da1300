#!/bin/bash

# ==============================================
# Lab Assignment 4 - Bash Section (Q1–Q6)
# ==============================================
# Instructions:
# - Fill in the code for each question in the TODO section.
# - DO NOT remove the "Qx:" markers (they are used for grading).
# - You may add helper commands, but outputs must match the expected format.
# ==============================================

# Q1
echo "Q1:"
# TODO: Extract unique words from essay.txt (case-insensitive), sort, and print in lowercase
tr '[:upper:]' '[:lower:]' <essay.txt| tr -c '[:alnum:]' '\n'|sort |uniq



echo ""


# Q2
echo "Q2:"
# TODO: Count regular files, directories, and symbolic links in current directory (non-recursive)
# Format:
# Files: X
# Directories: Y
# Symlinks: Z
# Your code here
files=$(find . -maxdepth 1 -type f | wc -l)
direct=$(find . -maxdepth 1 -type d| wc -l)
symbol_links=$(find . -maxdepth 1 -type l |wc -l)
echo "Files:$files"
echo "Directories:$direct"
echo"symlinks:$symbol_links"

echo ""


# Q3
echo "Q3:"
# TODO: Print top 5 largest files in 'bigfiles' directory (filename - size), sorted descending
# Format: filename - size
# Your code here
ls -lhS bigfiles 2>/dev/null |grep '^-'|head -n 5|awk'{print $9,'-',$5}'


echo ""


# Q4
echo "Q4:"
# TODO: Print essay.txt with line numbers (1-based, in format: "1: line content")
# Your code here
nl -w1 -s": "essay.txt


echo ""


# Q5
echo "Q5:"
# TODO: Print current user's info in format:
# User: <username>
# Home: <home_directory>
# Shell: <shell>
# Your code here
echo 'User : $USER'
echo 'Home : $HOME'
echo 'Shell : $SHELL'


echo ""


# Q6
echo "Q6:"
# TODO: Find all files modified in last 24 hours in current directory (non-recursive)
# Your code here
find . -maxdepth 1 -type f -mtime -1 -print