# ==============================================
# Lab Assignment 4 - Time Complexity (Q7–Q9)
# ==============================================
import time
import matplotlib.pyplot as plt
# Hint:
# Try plotting the time complexity data with matplotlib to visualize growth trends
# Will help in identifying the expected time complexity class

# ---------- Q7 ----------
def func1(n):
    s = 0
    for _ in range(n):
        j = 1
        while j * j <= n:
            s += 1
            j += 1
    return s
input_size=[1,5,10,50,100,500,1000,2000,4000,8000]
time_list=[]
for i in input_size:
    time_start=time.perf_counter()
    func1(i)
    time_end=time.perf_counter()
    time_taken=time_end-time_start
    time_list.append(time_taken)
plt.figure(figsize=(10,5))
plt.xlabel('input sizes')
plt.ylabel('time_taken')
plt.xscale('log')
plt.savefig('growth trends graph')
plt.title('graph plotting over various sizes')
plt.plot(input_size,time_list)
plt.show()

#the graph has a  nature of n{root}n 

def analyze_func1():
    """
    TODO:
    - Pick at least 3 n values
    - Measure runtime for each n and store in a dict {n: time}
    - Return (dict, "Estimated Complexity: O(?)")
    """
    input_size=[1,5,10,50,100,500,1000,2000,4000,8000]
    time_list=[]
    for i in input_size:
            time_start=time.perf_counter()
            func1(i)
            time_end=time.perf_counter()
            time_taken=time_end-time_start
            time_list.append(time_taken)
    plt.figure(figsize=(10,5))
    plt.xlabel('input sizes')
    plt.ylabel('time_taken')
    plt.xscale('log')
    plt.savefig('growth trends graph')
    plt.title('graph plotting over various sizes')
    plt.plot(input_size,time_list)
    plt.show()
    dic=dict(zip(input_size,time_list))
    return f'{dict}, "Estimated Complexity: O(2^n)'



# ---------- Q8 ----------
def func2(n):
    for _ in range(n):
        for _ in range(n):
            k = 1
            while k < n:
                k *= 2

def analyze_func2():
    """
    TODO: same pattern as analyze_func1
    """
    input_size=[1,5,10,50,100,500,1000,2000,4000,8000]
    time_list=[]
    for i in input_size:
            time_start=time.perf_counter()
            func2(i)
            time_end=time.perf_counter()
            time_taken=time_end-time_start
            time_list.append(time_taken)
    plt.figure(figsize=(10,5))
    plt.xlabel('input sizes')
    plt.ylabel('time_taken')
    plt.xscale('log')
    plt.savefig('growth trends graph')
    plt.title('graph plotting over various sizes')
    plt.plot(input_size,time_list)
    plt.show()
    dic=dict(zip(input_size,time_list))
    return f'{dict}, "Estimated Complexity: O(n^2)'


# ---------- Q9 ----------
def func3(n):
    if n <= 1:
        return 1
    return func3(n-1) + func3(n-1)

def analyze_func3():
    """
    TODO: same pattern as analyze_func1
    """
    input_size=[1,5,10,50,100,500,1000,2000,4000,8000]
    time_list=[]
    for i in input_size:
            time_start=time.perf_counter()
            func3(i)
            time_end=time.perf_counter()
            time_taken=time_end-time_start
            time_list.append(time_taken)
    plt.figure(figsize=(10,5))
    plt.xlabel('input sizes')
    plt.ylabel('time_taken')
    plt.xscale('log')
    plt.savefig('growth trends graph')
    plt.title('graph plotting over various sizes')
    plt.plot(input_size,time_list)
    plt.show()
    dic=dict(zip(input_size,time_list))
    return f'{dict}, "Estimated Complexity: O(2^n)'
    #T(n)=2⋅T(n−1)+O(1), thus a recurison loop gives 2**n times the t(1)