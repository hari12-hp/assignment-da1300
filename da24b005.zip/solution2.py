# ==============================================
# Lab Assignment 4 - String Manipulation (Q10–Q11)
# ==============================================

# Q10: Palindrome Rearrangement Checker
def palindrome_checker(s):
    # TODO:
    # - Return "Yes" if string can be rearranged into a palindrome
    # - Return "No" otherwise
    # - Return "input invalid" for empty or non-string
    #we can try to permute all possible ways and try to see if word among them is a palidrome, but it has o(n!) and its expensive, instead there is a night structure for this question
    #instead if we try to verify using the number of letters frequency in word, its actually the optimal way
    from collections import Counter


    if not isinstance(s, str) or len(s.strip()) == 0:
        return "input invalid"
    

    s = s.replace(" ", "").lower()
    counts = Counter(s)
    odd_counts = sum(1 for c in counts if counts[c] % 2 != 0)
    

    if odd_counts <= 1:
        return "Yes"
    else:
        return "No"




# Q11: String Rotation Validator
def rotation_checker(s1, s2):
    # TODO:
    # - Return True if s2 is a rotation of s1
    # - Return False otherwise
    # - Return "input invalid" if inputs are not strings or lengths differ
    #this question, again has a beautiful structure where , if we try to concatenate s1 with s1 and for sure we will get a set of combinations of s2 
    # where the substrings feel 
    #like rotated versions
    if not isinstance(s1, str) or not isinstance(s2, str):
        return "input invalid"
    if len(s1) != len(s2) or len(s1) == 0:
        return "input invalid"
    
    # Step 2: Rotation check
    if s2 in (s1 + s1):
        return True
    else:
        return False

